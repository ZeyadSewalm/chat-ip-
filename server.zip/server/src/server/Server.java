/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author DATA
 */
public class Server {

    static int port =1234;
    static ServerSocket server =null;
    public static void main(String[] args) {
        try {
            server= new ServerSocket(port);//step=1
            System.out.println("opening port number");
            Socket link = server.accept();//step=2;
            Scanner input=new Scanner(link.getInputStream());//step=3
            PrintWriter output=new PrintWriter(link.getOutputStream(),true);
            String message=input.nextLine();//step=4;
            while(!message.equals("CLOSE")){
            String response=message.toUpperCase();
            output.println(response);
            message=input.nextLine();
            }
            link.close();//step=5
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
