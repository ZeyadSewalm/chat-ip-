/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author DATA
 */
public class Client {

   static Socket link=null;
    public static void main(String[] args) {
       try {
           link=new Socket(InetAddress.getLocalHost(),1234);
            Scanner input=new Scanner(link.getInputStream());//
            PrintWriter output=new PrintWriter(link.getOutputStream(),true);
            Scanner inputFromConsel=new Scanner(System.in);
             System.out.println("enter message to server");
            String message=inputFromConsel.nextLine();
            while(!message.equals("CLOSE")){
           output.println(message);
          String servseReply= input.nextLine();
          System.out.println(servseReply);
          message=inputFromConsel.nextLine();
            }
            link.close();
           
       } catch (Exception ex) {
           Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
       }
    }
    
}
